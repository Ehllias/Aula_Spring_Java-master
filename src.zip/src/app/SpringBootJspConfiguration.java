package app;

import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringBootJspConfiguration extends WebMvcAutoConfiguration {
	
}